#ifndef __DS18B20_H__
#define __DS18B20_H__

void  Ds18b20ChangTemp();
void  Ds18b20ReadTempCom();
int Ds18b20ReadTemp();

#endif