#ifndef __DELAY_H_
#define __DELAY_H_
void Delay1ms(unsigned int y);
#endif