#ifndef __UARTINIT_H
#define __UARTINIT_H
void UartInit(void);		//4800bps@12.000MHz
#endif