#include "public.h"

void delay(u16 i)
{
	while(i--);
}
